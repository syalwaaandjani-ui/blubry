-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2025 at 05:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `bayar_pemilik`
--

CREATE TABLE `bayar_pemilik` (
  `IdByrPemilik` int(6) NOT NULL,
  `Tanggal` date NOT NULL,
  `JumlahByr` int(8) NOT NULL,
  `Keterangan` varchar(50) NOT NULL,
  `IdRekening` int(4) NOT NULL,
  `IdPem` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bayar_pemilik_detail`
--

CREATE TABLE `bayar_pemilik_detail` (
  `IdByrPemilik` int(6) NOT NULL,
  `IdRental` int(6) NOT NULL,
  `Jumlah` int(8) NOT NULL,
  `Keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cabang`
--

CREATE TABLE `cabang` (
  `NoCabang` char(3) NOT NULL,
  `Nama` varchar(40) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Kelurahan` varchar(30) NOT NULL,
  `Kecamatan` varchar(30) NOT NULL,
  `KabKota` varchar(30) NOT NULL,
  `Kodepos` char(5) NOT NULL,
  `Telp` varchar(15) DEFAULT NULL,
  `Email` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `IdMobil` int(4) NOT NULL,
  `Tahun` int(4) NOT NULL,
  `Warna` varchar(15) NOT NULL,
  `NoPelat` varchar(9) NOT NULL,
  `NoMesin` char(7) NOT NULL,
  `NoRangka` char(17) NOT NULL,
  `StatusMobil` int(1) NOT NULL,
  `NoCab` char(4) NOT NULL,
  `IdPem` int(4) NOT NULL,
  `IdTipe` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `IdPeg` char(5) NOT NULL,
  `Nama` varchar(15) NOT NULL,
  `NamaKel` varchar(15) NOT NULL,
  `JK` varchar(1) NOT NULL,
  `TmpLahir` varchar(30) NOT NULL,
  `TglLahir` date NOT NULL,
  `Alamat` varchar(40) NOT NULL,
  `Kelurahan` varchar(30) NOT NULL,
  `Kecamatan` varchar(30) NOT NULL,
  `KabKota` varchar(30) NOT NULL,
  `KodePos` char(5) NOT NULL,
  `Telp` varchar(15) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `NoCab` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `IdPelanggan` int(6) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `NIK` char(16) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Kelurahan` varchar(30) NOT NULL,
  `Kecamatan` varchar(30) NOT NULL,
  `KabKota` varchar(30) NOT NULL,
  `Telp` varchar(15) NOT NULL,
  `KodePos` char(5) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `IdPembayarran` int(6) NOT NULL,
  `TglPembayaran` date NOT NULL,
  `Keterangan` varchar(40) NOT NULL,
  `Jumlah` int(8) NOT NULL,
  `IdRental` int(6) NOT NULL,
  `IdPelanggan` int(6) NOT NULL,
  `IdPeg` char(4) NOT NULL,
  `IdTipeBayar` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pemilik`
--

CREATE TABLE `pemilik` (
  `IdPem` int(4) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Kelurahan` varchar(30) NOT NULL,
  `Kecamatan` varchar(30) NOT NULL,
  `KabKota` varchar(30) NOT NULL,
  `Kodepos` char(5) NOT NULL,
  `Telp` varchar(15) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `IdPeg` char(5) NOT NULL,
  `Mulai` int(4) NOT NULL,
  `Akhir` int(4) NOT NULL,
  `Jenjang` varchar(5) NOT NULL,
  `Gelar` varchar(5) NOT NULL,
  `Institusi` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rekening`
--

CREATE TABLE `rekening` (
  `IdRekening` int(6) NOT NULL,
  `NoRek` varchar(30) NOT NULL,
  `NamaRek` varchar(30) NOT NULL,
  `Bank` varchar(25) NOT NULL,
  `IdPem` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `IdRental` int(6) NOT NULL,
  `TglRental` date NOT NULL,
  `TtlTagihan` int(8) NOT NULL,
  `IdPelanggan` int(6) NOT NULL,
  `IdPeg` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rental_mobil`
--

CREATE TABLE `rental_mobil` (
  `IdRental` int(6) NOT NULL,
  `IdMobil` int(4) NOT NULL,
  `TglKeluar` date NOT NULL,
  `JamKeluar` time NOT NULL,
  `TglMasuk` date NOT NULL,
  `JamMasuk` time NOT NULL,
  `StatusRental` char(1) NOT NULL,
  `JumlahBayar` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tarif`
--

CREATE TABLE `tarif` (
  `IdTarif` int(4) NOT NULL,
  `IdTipe` int(2) NOT NULL,
  `TglMulai` date NOT NULL,
  `TglAkhir` date NOT NULL,
  `Harga` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tipe_mobil`
--

CREATE TABLE `tipe_mobil` (
  `IdTipe` int(2) NOT NULL,
  `Merek` varchar(12) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Model` varchar(10) NOT NULL,
  `Silinder` int(4) NOT NULL,
  `BhnBakar` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tipe_pembayaran`
--

CREATE TABLE `tipe_pembayaran` (
  `IdTipeBayar` int(5) NOT NULL,
  `TipeBayar` varchar(8) NOT NULL,
  `NoKartu` varchar(16) NOT NULL,
  `Bank` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bayar_pemilik`
--
ALTER TABLE `bayar_pemilik`
  ADD PRIMARY KEY (`IdByrPemilik`);

--
-- Indexes for table `cabang`
--
ALTER TABLE `cabang`
  ADD PRIMARY KEY (`NoCabang`),
  ADD UNIQUE KEY `Telp` (`Telp`,`Email`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`IdMobil`),
  ADD UNIQUE KEY `NoMesin` (`NoMesin`),
  ADD UNIQUE KEY `NoPelat` (`NoPelat`),
  ADD UNIQUE KEY `NoRangka` (`NoRangka`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`IdPeg`),
  ADD UNIQUE KEY `Telp` (`Telp`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`IdPelanggan`),
  ADD UNIQUE KEY `NIK` (`NIK`),
  ADD UNIQUE KEY `Telp` (`Telp`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`IdPembayarran`);

--
-- Indexes for table `pemilik`
--
ALTER TABLE `pemilik`
  ADD PRIMARY KEY (`IdPem`),
  ADD UNIQUE KEY `Telp` (`Telp`,`Email`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`IdPeg`,`Mulai`);

--
-- Indexes for table `rekening`
--
ALTER TABLE `rekening`
  ADD PRIMARY KEY (`IdRekening`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`IdRental`);

--
-- Indexes for table `tarif`
--
ALTER TABLE `tarif`
  ADD PRIMARY KEY (`IdTarif`);

--
-- Indexes for table `tipe_mobil`
--
ALTER TABLE `tipe_mobil`
  ADD PRIMARY KEY (`IdTipe`);

--
-- Indexes for table `tipe_pembayaran`
--
ALTER TABLE `tipe_pembayaran`
  ADD PRIMARY KEY (`IdTipeBayar`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pemilik`
--
ALTER TABLE `pemilik`
  MODIFY `IdPem` int(4) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
